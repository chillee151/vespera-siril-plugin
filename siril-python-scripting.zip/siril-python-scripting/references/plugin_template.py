"""
Siril Python Plugin Template
============================

A complete, working template for creating PyQt6-based Siril plugins.
Copy this file and modify for your specific needs.

Requirements:
- Siril 1.3+ with Python scripting support
- Place in: ~/Library/Application Support/org.siril.Siril/scripts/  (macOS)
"""

import sys
import os

# =============================================================================
# SIRILPY SETUP - Must come before any other imports that need installation
# =============================================================================

try:
    import sirilpy as s
    from sirilpy import LogColor
except ImportError:
    print("Error: sirilpy module not found. This script must be run within Siril.")
    sys.exit(1)

# Auto-install required packages (Siril will pip install if missing)
s.ensure_installed("PyQt6")

# =============================================================================
# NOW SAFE TO IMPORT INSTALLED PACKAGES
# =============================================================================

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget,
    QPushButton, QLabel, QProgressBar, QGroupBox, QComboBox,
    QCheckBox, QMessageBox
)
from PyQt6.QtCore import QThread, pyqtSignal, Qt

# =============================================================================
# CONSTANTS
# =============================================================================

VERSION = "1.0.0"

DARK_STYLESHEET = """
QMainWindow, QWidget { background-color: #2b2b2b; color: #ffffff; }
QGroupBox {
    border: 1px solid #555;
    border-radius: 5px;
    margin-top: 10px;
    padding-top: 10px;
    font-weight: bold;
}
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
QPushButton {
    background-color: #404040;
    border: 1px solid #555;
    padding: 8px 16px;
    border-radius: 4px;
}
QPushButton:hover { background-color: #505050; }
QPushButton:pressed { background-color: #353535; }
QPushButton:disabled { background-color: #333; color: #666; }
QComboBox, QSpinBox, QDoubleSpinBox {
    background-color: #404040;
    border: 1px solid #555;
    padding: 4px;
}
QCheckBox::indicator { width: 16px; height: 16px; }
QProgressBar {
    border: 1px solid #555;
    border-radius: 3px;
    text-align: center;
}
QProgressBar::chunk { background-color: #4a9f4a; }
QLabel#info { color: #aaaaaa; font-size: 11px; }
QLabel#status { font-weight: bold; }
"""

# =============================================================================
# PROCESSING THREAD
# =============================================================================

class ProcessingThread(QThread):
    """
    Background thread for long-running operations.

    Using a thread prevents the GUI from freezing during processing.
    All Siril commands should be executed in this thread.
    """
    progress = pyqtSignal(int, str)  # (percentage, status_message)
    finished = pyqtSignal(bool, str)  # (success, message)
    log = pyqtSignal(str)  # Log message for console

    def __init__(self, siril, workdir, settings):
        super().__init__()
        self.siril = siril
        self.workdir = workdir
        self.settings = settings

    def _log(self, message):
        """Emit log message to main thread."""
        self.log.emit(message)

    def run(self):
        """Main processing logic - override this for your plugin."""
        try:
            self.progress.emit(0, "Starting...")
            self._log("Processing started")

            # Example: Get image statistics
            self.progress.emit(25, "Getting image stats...")
            self.siril.cmd("stat")

            # Example: Background extraction
            self.progress.emit(50, "Extracting background...")
            # self.siril.cmd("subsky", "-rbf")

            # Example: Save result
            self.progress.emit(75, "Saving...")
            # self.siril.cmd("save", "result")

            self.progress.emit(100, "Complete!")
            self._log("Processing complete")
            self.finished.emit(True, "Processing completed successfully!")

        except Exception as e:
            self._log(f"ERROR: {e}")
            self.finished.emit(False, f"Error: {e}")

# =============================================================================
# MAIN WINDOW
# =============================================================================

class PluginWindow(QMainWindow):
    """Main plugin window with PyQt6 GUI."""

    def __init__(self, siril):
        super().__init__()
        self.siril = siril
        self.worker = None

        self._setup_ui()
        self._check_status()

    def _setup_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle(f"My Plugin v{VERSION}")
        self.setMinimumWidth(450)
        self.setMinimumHeight(400)
        self.setStyleSheet(DARK_STYLESHEET)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- Status Group ---
        status_group = QGroupBox("Status")
        status_layout = QVBoxLayout(status_group)

        self.lbl_workdir = QLabel("Working directory: ...")
        self.lbl_workdir.setObjectName("info")
        self.lbl_workdir.setWordWrap(True)
        status_layout.addWidget(self.lbl_workdir)

        self.lbl_image = QLabel("Image: checking...")
        status_layout.addWidget(self.lbl_image)

        layout.addWidget(status_group)

        # --- Options Group ---
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout(options_group)

        # Example dropdown
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Mode:"))
        self.combo_mode = QComboBox()
        self.combo_mode.addItems(["Standard", "Advanced", "Expert"])
        mode_row.addWidget(self.combo_mode, 1)
        options_layout.addLayout(mode_row)

        # Example checkbox
        self.chk_option = QCheckBox("Enable extra processing")
        self.chk_option.setChecked(True)
        options_layout.addWidget(self.chk_option)

        layout.addWidget(options_group)

        # --- Progress ---
        progress_group = QGroupBox("Progress")
        progress_layout = QVBoxLayout(progress_group)

        self.lbl_status = QLabel("Ready")
        self.lbl_status.setObjectName("status")
        progress_layout.addWidget(self.lbl_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        progress_layout.addWidget(self.progress_bar)

        layout.addWidget(progress_group)

        # --- Buttons ---
        button_row = QHBoxLayout()

        self.btn_start = QPushButton("Start Processing")
        self.btn_start.clicked.connect(self._start_processing)
        button_row.addWidget(self.btn_start)

        self.btn_close = QPushButton("Close")
        self.btn_close.clicked.connect(self.close)
        button_row.addWidget(self.btn_close)

        layout.addLayout(button_row)

        # Spacer
        layout.addStretch()

    def _check_status(self):
        """Check current Siril status and update UI."""
        try:
            workdir = self.siril.get_siril_wd()
            self.lbl_workdir.setText(f"Working directory: {workdir}")

            # Check if an image is loaded
            try:
                self.siril.cmd("stat")
                self.lbl_image.setText("Image: loaded")
                self.lbl_image.setStyleSheet("color: #88ff88;")
                self.btn_start.setEnabled(True)
            except Exception:
                self.lbl_image.setText("Image: no image loaded")
                self.lbl_image.setStyleSheet("color: #ff8888;")
                self.btn_start.setEnabled(False)

        except Exception as e:
            self.lbl_workdir.setText(f"Error: {e}")

    def _start_processing(self):
        """Start the processing thread."""
        self.btn_start.setEnabled(False)
        self.progress_bar.setValue(0)

        settings = {
            "mode": self.combo_mode.currentText(),
            "extra_processing": self.chk_option.isChecked(),
        }

        workdir = self.siril.get_siril_wd()
        self.worker = ProcessingThread(self.siril, workdir, settings)
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.log.connect(self._on_log)
        self.worker.start()

    def _on_progress(self, value, status):
        """Handle progress updates from worker thread."""
        self.progress_bar.setValue(value)
        self.lbl_status.setText(status)

    def _on_finished(self, success, message):
        """Handle completion from worker thread."""
        self.btn_start.setEnabled(True)

        if success:
            s.log(f"Plugin: {message}", LogColor.GREEN)
            self.lbl_status.setText("Complete!")
            self.lbl_status.setStyleSheet("color: #88ff88;")
        else:
            s.log(f"Plugin: {message}", LogColor.RED)
            self.lbl_status.setText("Failed")
            self.lbl_status.setStyleSheet("color: #ff8888;")
            QMessageBox.warning(self, "Error", message)

    def _on_log(self, message):
        """Handle log messages from worker thread."""
        s.log(f"Plugin: {message}", LogColor.SALMON)

# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

def main():
    """Main entry point - called when script runs in Siril."""
    try:
        # Get or create QApplication instance
        app = QApplication.instance()
        if not app:
            app = QApplication(sys.argv)

        # Connect to Siril
        siril = s.SirilInterface()

        try:
            siril.connect()
        except Exception as e:
            QMessageBox.critical(None, "Connection Error",
                               f"Could not connect to Siril.\n{e}")
            return

        s.log("Plugin started", LogColor.GREEN)

        # Create and show window
        window = PluginWindow(siril)
        window.show()

        # Run event loop
        app.exec()

    except Exception as e:
        s.log(f"Plugin error: {e}", LogColor.RED)
        raise


if __name__ == "__main__":
    main()
