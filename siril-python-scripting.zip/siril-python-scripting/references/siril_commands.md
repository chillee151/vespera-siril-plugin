# Siril Command Reference for Python Scripts

This reference covers the most commonly used Siril commands when developing Python plugins.
All commands are executed via `siril.cmd("command", "arg1", "arg2", ...)`.

## File Operations

### cd - Change Directory
```python
siril.cmd("cd", "path")
siril.cmd("cd", "..")        # Parent directory
siril.cmd("cd", "subfolder") # Relative path
```

### load - Load Image
```python
siril.cmd("load", "filename")       # Loads filename.fit
siril.cmd("load", "result_00001")   # Load from sequence
```
Note: Do not include file extension.

### save - Save Current Image
```python
siril.cmd("save", "output_name")
siril.cmd("save", "result_$LIVETIME:%d$s")  # With integration time
```

### convert - Convert Files to Sequence
```python
siril.cmd("convert", "prefix", "-out=output_dir")
siril.cmd("convert", "img-", "-out=masters", "-start=1")
```
**Important:** Uses filename prefix, NOT wildcards. `img-*.fits` will fail!

## Sequence Operations

### calibrate - Apply Calibration
```python
# Dark subtraction only
siril.cmd("calibrate", "light", "-dark=master_dark", "-prefix=pp_")

# Full calibration
siril.cmd("calibrate", "light",
          "-dark=master_dark",
          "-flat=master_flat",
          "-bias=master_bias",
          "-prefix=pp_")

# With cosmetic correction
siril.cmd("calibrate", "light", "-dark=master_dark", "-cc=dark", "-prefix=pp_")
```

### register - Align Frames
```python
# Standard registration
siril.cmd("register", "pp_light")

# With drizzle (for field rotation)
siril.cmd("register", "pp_light", "-drizzle")

# Planetary (single reference)
siril.cmd("register", "pp_light", "-2pass")
```

### stack - Combine Registered Frames
```python
# Basic with rejection
siril.cmd("stack", "r_pp_light", "rej", "3", "3", "-out=result")

# Full recommended command
siril.cmd("stack", "r_pp_light",
          "rej", str(sigma_low), str(sigma_high),
          "-norm=addscale",
          "-output_norm",
          "-32b",
          "-out=result")

# Rejection methods: "rej" (sigma), "winsorized", "linearfit", "none"
```

**Stack Flags:**
| Flag | Description |
|------|-------------|
| `-norm=addscale` | Normalize using additive scaling |
| `-norm=mul` | Normalize using multiplicative |
| `-output_norm` | Normalize output (0-1 for 32b, 0-65535 for 16b) |
| `-32b` | Force 32-bit float output |
| `-rgb_equal` | Equalize RGB channels (can cause issues) |
| `-out=name` | Output filename |

## Image Processing

### mirrorx / mirrory - Flip Image
```python
siril.cmd("mirrorx")              # Horizontal flip
siril.cmd("mirrorx", "-bottomup") # Convert to bottom-up format
siril.cmd("mirrory")              # Vertical flip
```

### subsky - Background Extraction
```python
siril.cmd("subsky", "-rbf")       # RBF interpolation (recommended)
siril.cmd("subsky", "-rbf", "-samples=20", "-tolerance=1.0", "-smooth=0.5")
```

### pcc - Photometric Color Calibration
```python
siril.cmd("pcc")
siril.cmd("pcc", "-limitmag=12")  # Limit to brighter stars
siril.cmd("pcc", "-catalog=nomad") # Specify catalog
```
**Warning:** PCC embeds ICC profile. Use `icc_remove` before VeraLux.

### spcc - Spectrophotometric Color Calibration
```python
siril.cmd("spcc")
siril.cmd("spcc", "-limitmag=10")
```

### platesolve - Astrometric Solving
```python
siril.cmd("platesolve")
siril.cmd("platesolve", "-force")  # Re-solve even if already solved
siril.cmd("platesolve", "-catalog=gaia")
```

### icc_remove - Remove ICC Profile
```python
siril.cmd("icc_remove")
```
**Critical:** Run this before saving if image will be processed in VeraLux.

### stat - Image Statistics
```python
siril.cmd("stat")
```
Outputs: Mean, Median, Sigma, Min, Max, bgnoise for each channel.

### split_cfa - Separate Bayer Channels
```python
siril.cmd("split_cfa")
# Creates: filename_CFA0, filename_CFA1, filename_CFA2, filename_CFA3
```

### rgbcomp - Create RGB Composite
```python
siril.cmd("rgbcomp", "red_file", "green_file", "blue_file", "-out=result")
# For HOO palette: Ha for R, OIII for G and B
siril.cmd("rgbcomp", "Ha_result", "OIII_result", "OIII_result", "-out=HOO_result")
```

## Stretching & Processing

### autostretch - Auto Histogram Stretch
```python
siril.cmd("autostretch")
siril.cmd("autostretch", "-linked")  # Link RGB channels
```

### asinh - Arcsinh Stretch
```python
siril.cmd("asinh", "-human")
siril.cmd("asinh", "100")  # Stretch factor
```

### ght - Generalized Hyperbolic Stretch
```python
siril.cmd("ght", "-D=1.5", "-B=0.0", "-LP=0.0", "-SP=0.0", "-HP=1.0")
```

### clahe - Contrast Limited Adaptive Histogram
```python
siril.cmd("clahe", "2", "8")  # clip_limit, tiles
```

## Utility Commands

### requires - Check Version
```python
siril.cmd("requires", "1.3.0")  # Fails if Siril version < 1.3.0
```

### set16bits / set32bits - Set Bit Depth Mode
```python
siril.cmd("set16bits")  # Force 16-bit mode
siril.cmd("set32bits")  # Force 32-bit mode
```
Note: These set a preference, they don't convert the current image.

### visu - Set Display Range
```python
siril.cmd("visu", "0", "65535")  # Set black/white points
```

## Sequence Variables for Filenames

When saving, special variables can be included:

| Variable | Description | Example Output |
|----------|-------------|----------------|
| `$LIVETIME:%d$s` | Integration time in seconds | `result_1330s.fit` |
| `$DATE$` | Observation date | `result_2024-01-15.fit` |
| `$FILTER$` | Filter name from header | `result_Ha.fit` |
| `$OBJECT$` | Object name from header | `result_M42.fit` |

Example:
```python
siril.cmd("save", "result_$LIVETIME:%d$s")
```

## Full Command Documentation

For complete documentation of all Siril commands:
https://siril.readthedocs.io/en/stable/Commands.html
