---
name: siril-python-scripting
description: |
  This skill provides comprehensive guidance for developing Python plugins for Siril, the open-source astrophotography image processing software. This skill should be used when the user wants to create, modify, or debug Python scripts that run within Siril 1.3+ using the sirilpy API. It covers the correct API patterns, script installation locations per operating system, common commands with parameters, PyQt6 GUI integration patterns, and known gotchas learned from real-world development. This skill is essential for avoiding common pitfalls like incorrect class names (Siril vs SirilInterface), wrong method calls (get_cwd vs get_siril_wd), ICC profile issues with VeraLux, and script location errors.
---

# Siril Python Scripting

This skill enables development of Python plugins for Siril (astrophotography software) using the `sirilpy` API introduced in Siril 1.3+.

## When to Use This Skill

- Creating new Siril Python plugins/scripts
- Debugging sirilpy import errors or API issues
- Adding PyQt6 GUI to Siril scripts
- Understanding Siril command syntax and parameters
- Troubleshooting script loading issues

## sirilpy API Reference

### CRITICAL: Correct Import Pattern

```python
import sirilpy as s
from sirilpy import LogColor

# Auto-install dependencies (runs pip if needed)
s.ensure_installed("PyQt6", "numpy")

# Create interface - NOT Siril(), that class doesn't exist!
siril = s.SirilInterface()
siril.connect()

# Execute Siril commands
siril.cmd("command", "arg1", "arg2")

# Log to Siril console
s.log("message", LogColor.GREEN)

# Get working directory - NOT get_cwd()!
workdir = siril.get_siril_wd()
```

### Common Mistakes to AVOID

| Wrong | Correct | Notes |
|-------|---------|-------|
| `from sirilpy import Siril` | `siril = s.SirilInterface()` | `Siril` class doesn't exist |
| `from sirilpy import SirilError` | `except Exception` | `SirilError` doesn't exist |
| `siril.get_cwd()` | `siril.get_siril_wd()` | Wrong method name |
| `siril.log()` | `s.log()` | Log is module function, not method |

### Available LogColor Values

```python
from sirilpy import LogColor

LogColor.GREEN    # Success messages
LogColor.RED      # Errors
LogColor.SALMON   # Warnings
LogColor.ORANGE   # Cautions
LogColor.BLUE     # Info
```

## Script Installation by Operating System

### macOS

Python scripts MUST be placed in:
```
~/Library/Application Support/org.siril.Siril/scripts/
```

**Full path example:**
```
/Users/username/Library/Application Support/org.siril.Siril/scripts/
```

**Common wrong locations (do NOT use):**
- `~/Library/Application Support/siril/scripts/` - wrong folder name
- `~/Library/Application Support/org.siril.Siril/siril-scripts/` - third-party plugins folder
- `/Applications/Siril.app/Contents/Resources/scripts/` - system scripts

### Linux

```
~/.local/share/siril/scripts/
```

Or check Siril preferences for custom script path.

### Windows

```
%APPDATA%\siril\scripts\
```

Typically: `C:\Users\username\AppData\Roaming\siril\scripts\`

### Loading Scripts in Siril

1. Place `.py` file in scripts folder (or create symlink)
2. In Siril: **Scripts → Refresh Scripts** (or restart Siril)
3. Access via: **Scripts → Python Scripts → [Script Name]**

## Common Siril Commands

### File Operations

```python
siril.cmd("cd", "subfolder")           # Change directory
siril.cmd("load", "filename")          # Load FITS file (no extension needed)
siril.cmd("save", "filename")          # Save current image
siril.cmd("convert", "prefix", "-out=output_dir")  # Convert files to sequence
```

### Calibration & Registration

```python
# Calibrate with dark subtraction
siril.cmd("calibrate", "light", "-dark=dark_stacked", "-prefix=pp_")

# Register frames (standard)
siril.cmd("register", "pp_light")

# Register with Bayer Drizzle (for field rotation)
siril.cmd("register", "pp_light", "-drizzle")
```

### Stacking

```python
# Basic stack with sigma rejection
siril.cmd("stack", "r_pp_light", "rej", "3", "3", "-norm=addscale", "-out=result")

# Full recommended stack command
siril.cmd("stack", "r_pp_light",
          "rej", str(sigma_low), str(sigma_high),
          "-norm=addscale", "-output_norm", "-32b", "-out=result")
```

**Stack flags explained:**
- `-norm=addscale` - Normalize frames before stacking
- `-output_norm` - Normalize output (0-1 for 32-bit, 0-65535 for 16-bit)
- `-32b` - Force 32-bit float output (higher precision)
- `-rgb_equal` - Equalize RGB channels (can cause brightness issues, use cautiously)

### Image Processing

```python
siril.cmd("mirrorx", "-bottomup")      # Flip image vertically
siril.cmd("subsky", "-rbf")            # Background extraction
siril.cmd("pcc")                        # Photometric Color Calibration
siril.cmd("platesolve")                 # Plate solve (astrometry)
siril.cmd("icc_remove")                 # Remove ICC profile (important for VeraLux)
siril.cmd("split_cfa")                  # Split Bayer channels
siril.cmd("stat")                       # Show image statistics
```

### Sequence Variables in Filenames

```python
# Include integration time in output filename
siril.cmd("save", "result_$LIVETIME:%d$s")  # e.g., "result_1330s.fit"
```

## PyQt6 GUI Integration

### Basic Plugin Template

See `references/plugin_template.py` for a complete working template with:
- Proper sirilpy imports and connection
- QThread for background processing
- Signal/slot communication
- Dark theme stylesheet
- Error handling patterns

### Dark Theme Stylesheet

```python
DARK_STYLESHEET = """
QMainWindow, QWidget { background-color: #2b2b2b; color: #ffffff; }
QGroupBox {
    border: 1px solid #555;
    border-radius: 5px;
    margin-top: 10px;
    padding-top: 10px;
    font-weight: bold;
}
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
QPushButton {
    background-color: #404040;
    border: 1px solid #555;
    padding: 8px 16px;
    border-radius: 4px;
}
QPushButton:hover { background-color: #505050; }
QPushButton:pressed { background-color: #353535; }
QPushButton:disabled { background-color: #333; color: #666; }
QComboBox, QSpinBox, QDoubleSpinBox {
    background-color: #404040;
    border: 1px solid #555;
    padding: 4px;
}
QCheckBox::indicator { width: 16px; height: 16px; }
QProgressBar {
    border: 1px solid #555;
    border-radius: 3px;
    text-align: center;
}
QProgressBar::chunk { background-color: #4a9f4a; }
"""
```

## Known Issues and Gotchas

### ICC Profile Issues with VeraLux

When using Photometric Color Calibration (PCC), Siril embeds an ICC profile in the FITS file. This can cause VeraLux HyperMetric Stretch to produce overexposed results.

**Solution:** Always run `icc_remove` before saving if the image will be processed in VeraLux:

```python
siril.cmd("load", "result")
siril.cmd("icc_remove")  # Remove ICC profile for VeraLux compatibility
siril.cmd("save", "result_final")
```

### 32-bit vs 16-bit Output

- With `-32b -output_norm`: Output is normalized to 0-1 range
- With 16-bit (default) + `-output_norm`: Output is normalized to 0-65535 range
- Siril config `force_16bit=true` forces 16-bit output regardless of flags

### Convert Command Patterns

The `convert` command expects a filename prefix, not a glob pattern:

```python
# Correct - use filename prefix
siril.cmd("convert", "img-", "-out=output")

# Wrong - wildcards not allowed
siril.cmd("convert", "img-*.fits", "-out=output")  # Will fail!
```

### Working Directory Management

Always track the working directory when using `cd`:

```python
# Save original directory
original_dir = self.siril.get_siril_wd()

# Change to subfolder
siril.cmd("cd", "process")

# Do work...

# Return to original
siril.cmd("cd", original_dir)
```

## Resources

### references/

- `plugin_template.py` - Complete working PyQt6 plugin template
- `siril_commands.md` - Comprehensive command reference with parameters

### Example Plugins for Study

When developing Siril plugins, examine these well-built examples:
- `VeraLux_HyperMetric_Stretch.py` - Complex PyQt6 GUI, image processing
- `VeraLux_Silentium.py` - File cleanup patterns, threading
- Located in: `~/Library/Application Support/org.siril.Siril/siril-scripts/VeraLux/`

## Quick Reference: Full Command Documentation

For complete command documentation:
- Siril Commands Reference: https://siril.readthedocs.io/en/stable/Commands.html
- sirilpy API (in Siril): Help → Scripting → Python API
